# -*- coding: utf-8 -*-
#  Copyright 2023 Guillaume Grossetie
from blockdiag.command import main

main()
